
import sys, json, math, hashlib, ast, argparse
from pathlib import Path
from collections import Counter
sys.dont_write_bytecode=True
parser=argparse.ArgumentParser(description='Read-only CPU replay of frozen native contact raw samples using existing producer functions')
parser.add_argument('--root', action='append', help='Frozen stage root to audit; repeat for multiple runs')
parser.add_argument('--source', default='D:/yacs/work/pcg365/d0e76c6026befb82c3862d96f8f3b719cfb4d8ed/natural20-contact03', help='Immutable staged scripts root used as audit reader')
parser.add_argument('--expected-producer-sha', default='d0e76c6026befb82c3862d96f8f3b719cfb4d8ed')
args=parser.parse_args()
source=Path(args.source).resolve()
audit_path=Path(__file__).resolve()
audit_reader={'script_path':str(audit_path),'script_sha256':hashlib.sha256(audit_path.read_bytes()).hexdigest(),'script_git_sha':None,'function_source_root':str(source),'function_source_kind':'FROZEN_STAGED_PRODUCER_FILES','python_version':sys.version,'python_executable':sys.executable,'bytecode_writes':False}
sys.path.insert(0,str(source))
from scripts.assets.pcg_boulder_support import solve_support
from scripts.assets.pcg_rock_contact_policy import evaluate, trial_policy, refined_trial_policy
tree=ast.parse((source/'scripts/ue/sa_calobra_pcg_collection_contact.py').read_text(encoding='utf-8'))
def require_for_existing_marker(condition, message):
    if not condition: raise ValueError(message)
ns={'require':require_for_existing_marker}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('measurement','complete','verify_marker','verify_all_marker')],type_ignores=[]),'existing_contact_helpers','exec'),ns)
base=Path('D:/yacs/work/pcg365/d0e76c6026befb82c3862d96f8f3b719cfb4d8ed')
expected=args.expected_producer_sha
summaries=[]
roots=[Path(p).resolve() for p in args.root] if args.root else [base/'natural20-contact02',base/'natural20-contact03']
for root in roots:
    token=root.name
    if not root.exists(): continue
    errors=[]
    def check(condition, label, **detail):
        if not condition: errors.append({'check':label,**detail})
    stats=Counter(); decisions=Counter(); reasons=Counter(); assets={}; casesets=[]
    spans={k:[] for k in ('slope_deg','embedding_fraction','exposed_height_fraction','exposed_ray_fraction','root_delta_cm','embedding_delta_cm','height_cm','root_zero_cm','root_nonpenetrating_cm')}
    stage_manifest=json.loads((root/'staged-files.json').read_bytes())
    check(stage_manifest['expected_head']==expected,'STAGED_PRODUCER_SHA')
    source_hashes={}
    for rel in ('scripts/assets/pcg_boulder_support.py','scripts/assets/pcg_rock_contact_policy.py','scripts/ue/sa_calobra_pcg_collection_contact.py','scripts/ue/sa_calobra_pcg_rock_qualification.py'):
        p=root/rel
        if p.exists():
            h=hashlib.sha256(p.read_bytes()).hexdigest()
            source_hashes[rel]={'sha256':h,'reader_bytes_equal':p.read_bytes()==(source/rel).read_bytes()}
            check(source_hashes[rel]['reader_bytes_equal'],'SOURCE_BYTES_DRIFT',path=rel)
    batch_inputs=[]; receipt_snapshots=[]; missing_completion=[]; completion_markers=[]; all_receipt=None
    batch_directories=sorted((root/'proof').glob('collection-contact-[0-9][0-9]'))
    all_directory=root/'proof/collection-contact-all'
    mode='SINGLE_PROCESS_ALL_BATCHES' if all_directory.exists() else 'PER_BATCH_PROCESSES'
    check(not (all_directory.exists() and batch_directories),'MIXED_CONTACT_PROCESS_LAYOUTS')
    def read_snapshot(path):
        blob=path.read_bytes()
        receipt_snapshots.append((path,blob))
        return json.loads(blob)
    def read_completion(path, action, index=None):
        if not path.exists():
            missing_completion.append(action)
            return False
        marker=read_snapshot(path)
        completion_markers.append({'path':str(path.relative_to(root)),'action':marker.get('action'),'exit_code':marker.get('exit_code'),'code_sha':marker.get('code_sha'),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
        validator='verify_all_marker' if action=='collection-contact-all' else 'verify_marker'
        try:
            if validator not in ns: raise ValueError('Frozen reader lacks '+validator)
            if index is None: ns[validator](marker,expected)
            else: ns[validator](marker,expected,index)
        except (KeyError,ValueError,TypeError) as exc:
            check(False,'COMPLETION_MARKER',action=action,error=str(exc))
            return False
        return True
    if mode=='SINGLE_PROCESS_ALL_BATCHES':
        rp=all_directory/'collection-contact-all-receipt.json'
        if not rp.exists():
            check(False,'ALL_RECEIPT_MISSING',path=str(rp))
        else:
            all_receipt=read_snapshot(rp)
            completed=read_completion(all_directory/'launcher-completed.json','collection-contact-all')
            check(all_receipt.get('code_sha')==expected and all_receipt.get('action')=='collection-contact-all','ALL_RECEIPT_IDENTITY')
            check(all_receipt.get('status')=='COLLECTION_CONTACT_ALL_MEASURED' and all_receipt.get('contact_execution_mode')==mode,'ALL_RECEIPT_STATUS')
            check(all_receipt.get('asset_compilation_loading_barrier_completed') is True,'ALL_LOADING_BARRIER')
            check(all_receipt.get('terrain_file_before')==all_receipt.get('terrain_file_after'),'ALL_TERRAIN_UNCHANGED')
            check(all(all_receipt.get(k) is False for k in ('terrain_modified','map_saved','placement','full_qualification')) and all_receipt.get('qualified_assets')==[],'ALL_SCOPE_FLAGS')
            batches=all_receipt.get('batches',[])
            check(len(batches)==10,'ALL_TEN_BATCHES')
            check(len(all_receipt.get('meshes',[]))==20 and len({m['id'] for m in all_receipt.get('meshes',[])})==20,'ALL_TWENTY_UNIQUE_MESHES')
            for index,batch in enumerate(batches):
                check(batch.get('directory')==f'batch-{index:02d}','INLINE_BATCH_DIRECTORY',index=index)
                if batch.get('directory')!=f'batch-{index:02d}': continue
                directory=all_directory/batch['directory']
                check(not (directory/'launcher-completed.json').exists(),'FORBIDDEN_CHILD_COMPLETION_MARKER',batch=directory.name)
                result=batch['result']
                for key in ('catalog','source_contract','contact_request','terrain_file_before','terrain_file_after','ground_transform'):
                    check(result.get(key)==all_receipt.get(key),'INLINE_PARENT_IDENTITY',batch=directory.name,field=key)
                ordered=sorted(all_receipt['meshes'],key=lambda mesh:mesh['id'])
                check(result.get('meshes')==ordered[index*2:index*2+2],'INLINE_MESH_PARTITION',batch=directory.name)
                batch_inputs.append((directory,rp,result,completed,index))
    else:
        for directory in batch_directories:
            rp=directory/(directory.name+'-receipt.json')
            if not rp.exists(): continue
            try: receipt=read_snapshot(rp)
            except (OSError,json.JSONDecodeError):
                stats['inflight_receipt_skipped']+=1; continue
            index=int(directory.name[-2:])
            completed=read_completion(directory/'launcher-completed.json',directory.name,index)
            batch_inputs.append((directory,rp,receipt,completed,index))
    contact=json.loads((root/'contact-request.json').read_bytes())
    contact_identity={'bytes':(root/'contact-request.json').stat().st_size,'sha256':hashlib.sha256((root/'contact-request.json').read_bytes()).hexdigest()}
    cases_flat=[]
    for directory,rp,receipt,completed,index in batch_inputs:
        stats['batch_receipts']+=1
        stats['completed_batches']+=int(completed)
        if not completed: stats['batches_without_completion']+=1
        check(type(receipt.get('batch_index')) is int and receipt['batch_index']==index,'BATCH_INDEX',batch=directory.name)
        check(receipt.get('status')=='COLLECTION_CONTACT_BATCH_MEASURED','BATCH_STATUS',batch=directory.name)
        check(receipt.get('contact_request')==contact_identity,'CONTACT_REQUEST_IDENTITY',batch=directory.name)
        check(receipt.get('terrain_file_before')==receipt.get('terrain_file_after'),'BATCH_TERRAIN_UNCHANGED',batch=directory.name)
        check(all(receipt.get(k) is False for k in ('terrain_modified','map_saved','placement','full_qualification')) and receipt.get('qualified_assets')==[],'BATCH_SCOPE_FLAGS',batch=directory.name)
        cases_flat.extend(receipt['cases'])
        meshes={m['id']:m for m in receipt['meshes']}
        check(receipt['code_sha']==expected,'RECEIPT_SHA',batch=directory.name)
        check(len(receipt['cases'])==10,'CASE_COUNT',batch=directory.name)
        check({(c['mesh_id'],c['point_index']) for c in receipt['cases']}=={(m,i) for m in meshes for i in range(5)},'CASE_MATRIX',batch=directory.name)
        for case in receipt['cases']:
            key=case['mesh_id']+'@'+str(case['point_index'])
            point=contact['points'][case['point_index']]
            check(case['candidate_id']==point['candidate_id'] and case['world_xy_cm']==point['world_xy_cm'],'AUTHENTICATED_POINT',case=key)
            mesh=meshes[case['mesh_id']]; origin=mesh['bounds_cm']['origin']; extent=mesh['bounds_cm']['extent']
            computed=[]
            for grid in case['grids']:
                raw_id=grid['raw_samples']; p=directory/raw_id['path']; raw_bytes=p.read_bytes(); raw=json.loads(raw_bytes)
                check(len(raw_bytes)==raw_id['bytes'] and hashlib.sha256(raw_bytes).hexdigest()==raw_id['sha256'],'RAW_IDENTITY',case=key,grid=grid['grid_size'])
                rows=raw['support_rows']; rejected=raw['rejected_rows']; size=grid['grid_size']
                stats['raw_grids']+=1; stats['support_rows']+=len(rows); stats['rejected_rows']+=len(rejected)
                counts=Counter(r['status'] for r in rejected)
                check(set(counts)<= {'PAIRED_MESH_MISS','UNPAIRED_MESH_HIT','MISSING_GROUND'},'UNKNOWN_REJECT_STATUS',case=key,grid=size)
                points=[tuple(row['local_xy_cm']) for row in rows+rejected]
                expected_points={(origin[0]+extent[0]*(2*ix/(size-1)-1),origin[1]+extent[1]*(2*iy/(size-1)-1)) for iy in range(size) for ix in range(size)}
                check(len(points)==size*size and len(set(points))==size*size and set(points)==expected_points,'GRID_MATRIX',case=key,grid=size)
                slope=0.
                for idx,row in enumerate(rows):
                    x,y=row['local_xy_cm']; wx,wy=row['world_xy_cm']; normal=row['ground_normal']
                    check([wx,wy]==[case['world_xy_cm'][0]+x,case['world_xy_cm'][1]+y],'WORLD_XY',case=key,grid=size,row=idx)
                    check(all(math.isfinite(v) for v in (*normal,row['bottom_z_cm'],row['top_z_cm'],row['ground_z_cm'])),'FINITE_UNITS',case=key,grid=size,row=idx)
                    length=math.sqrt(sum(v*v for v in normal))
                    actual=math.degrees(math.acos(max(-1.,min(1.,normal[2]/length))))
                    check(actual==row['ground_slope_deg'],'ROW_SLOPE',case=key,grid=size,row=idx)
                    slope=max(slope,actual)
                    check(origin[2]-extent[2]-1e-5<=row['bottom_z_cm']<=row['top_z_cm']<=origin[2]+extent[2]+1e-5,'LOCAL_Z_BOUNDS',case=key,grid=size,row=idx)
                fit=None; fit_error=None
                if rows:
                    try:
                        fit=solve_support(rows)
                        fit['max_positive_bottom_gap_cm']=max(0.,max(p['bottom_gap_cm'] for p in fit['samples']))
                        fitted=fit.pop('samples')
                        check(all(row.get('fit')==f for row,f in zip(rows,fitted)),'ROW_FIT',case=key,grid=size)
                        offsets=[row['ground_z_cm']-row['bottom_z_cm'] for row in rows]
                        check(fit['root_zero_sampled_air_cm']==min(offsets) and fit['root_nonpenetrating_cm']==max(offsets) and fit['required_embedding_cm']==max(offsets)-min(offsets),'INDEPENDENT_ROOT_EMBEDDING',case=key,grid=size)
                        check(fit['max_penetration_cm']==fit['required_embedding_cm'] and fit['max_positive_bottom_gap_cm']==0.,'ZERO_SAMPLED_GAP',case=key,grid=size)
                    except ValueError as exc: fit_error=str(exc)
                cg={'grid_size':size,'sample_count':size*size-counts['PAIRED_MESH_MISS'],'valid_ground_count':len(rows),'paired_misses':counts['PAIRED_MESH_MISS'],'unpaired_mesh_hits':counts['UNPAIRED_MESH_HIT'],'missing_ground_count':counts['MISSING_GROUND'],'max_local_slope_deg':slope,'fit':fit,'fit_error':fit_error}
                check(cg=={k:v for k,v in grid.items() if k!='raw_samples'},'GRID_RECEIPT',case=key,grid=size)
                computed.append(cg)
            check([g['grid_size'] for g in computed] in ([33,65],[33,65,129]),'GRID_SEQUENCE',case=key)
            co,fi=computed[:2]
            decision={'status':'REJECTED','reasons':['INCOMPLETE_GROUND_OR_SUPPORT']}
            if ns['complete'](co) and ns['complete'](fi):
                measurement=ns['measurement'](mesh,co,fi)
                decision=evaluate(measurement,trial_policy())
                if len(computed)==3:
                    check(set(decision['reasons'])<={'ROOT_NOT_CONVERGED','EMBEDDING_NOT_CONVERGED'} and bool(decision['reasons']),'REFINEMENT_ENTRY',case=key)
                    check(case['initial_measurement']==measurement and case['initial_policy_decision']==decision,'INITIAL_DECISION',case=key)
                    if ns['complete'](computed[2]):
                        measurement=ns['measurement'](mesh,fi,computed[2]); decision=evaluate(measurement,refined_trial_policy())
                    else: decision={'status':'REJECTED','reasons':['INCOMPLETE_REFINED_GROUND_OR_SUPPORT']}
                check(measurement==case['measurement'],'MEASUREMENT_RECEIPT',case=key)
                fit=measurement['fit']
                spans['height_cm'].append(measurement['height_cm']);spans['slope_deg'].append(measurement['max_local_slope_deg'])
                spans['root_zero_cm'].append(fit['root_zero_sampled_air_cm']);spans['root_nonpenetrating_cm'].append(fit['root_nonpenetrating_cm'])
                for k in decision.get('metrics',{}):
                    if k in spans:spans[k].append(decision['metrics'][k])
            check(decision==case['policy_decision'],'POLICY_DECISION_RECEIPT',case=key)
            stats['cases']+=1;stats['completed_cases']+=int(completed); decisions[decision['status']]+=1;reasons.update(decision['reasons'])
            assets.setdefault(case['mesh_id'],Counter())[decision['status']]+=1
            casesets.append({'case':key,'completed':completed,'decision':decision['status']})
    for receipt_path,original_blob in receipt_snapshots:
        check(receipt_path.read_bytes()==original_blob,'RECEIPT_CHANGED_DURING_AUDIT',path=str(receipt_path))
    aggregate_path=root/'proof/collection-contact-reload/collection-contact-reload-receipt.json'
    aggregate_marker=root/'proof/collection-contact-reload/launcher-completed.json'
    aggregate_readback={'receipt_present':aggregate_path.exists(),'completion_marker_present':aggregate_marker.exists(),'completion_status':'NOT_RUN'}
    if aggregate_path.exists():
        aggregate_bytes=aggregate_path.read_bytes()
        aggregate_readback.update(receipt_sha256=hashlib.sha256(aggregate_bytes).hexdigest(),receipt_bytes=len(aggregate_bytes),completion_status='BLOCKED_MISSING_COMPLETION')
    if aggregate_marker.exists():
        aggregate_done=json.loads(aggregate_marker.read_bytes())
        aggregate_readback['marker']=aggregate_done
        aggregate_valid=(type(aggregate_done.get('exit_code')) is int and aggregate_done['exit_code']==0 and aggregate_done.get('code_sha')==expected and aggregate_done.get('action')=='collection-contact-reload' and aggregate_done.get('staged_bytes_unchanged') is True and aggregate_done.get('proof_admission')=='LOCAL_DIAGNOSTIC_ONLY')
        aggregate_readback['completion_status']='PASS' if aggregate_valid else 'FAIL'
        check(aggregate_valid,'AGGREGATE_COMPLETION_MARKER')
    render_evidence={'receipt_present':(root/'proof/collection-contact-render/collection-contact-render-receipt.json').exists(),'completion_marker_present':(root/'proof/collection-contact-render/launcher-completed.json').exists(),'png_count':len(list((root/'proof').rglob('*.png')))}
    if all_receipt is not None:
        check(len(cases_flat)==100 and {(c['mesh_id'],c['point_index']) for c in cases_flat}=={(m['id'],i) for m in all_receipt['meshes'] for i in range(5)},'ALL_CASE_MATRIX')
        reload_path=root/'proof/collection-contact-reload/collection-contact-reload-receipt.json'
        if reload_path.exists():
            reloaded=json.loads(reload_path.read_bytes())
            all_path=all_directory/'collection-contact-all-receipt.json'
            expected_ref={'path':str(all_path.relative_to(root)),'bytes':all_path.stat().st_size,'sha256':hashlib.sha256(all_path.read_bytes()).hexdigest()}
            check(reloaded.get('code_sha')==expected and reloaded.get('contact_execution_mode')==mode,'AGGREGATE_IDENTITY')
            check(reloaded.get('cases')==cases_flat,'AGGREGATE_CASES')
            refs=reloaded.get('batches',[])
            check(len(refs)==1 and {**refs[0],'path':refs[0]['path'].replace('\\','/')}=={**expected_ref,'path':expected_ref['path'].replace('\\','/')},'AGGREGATE_PARENT_REFERENCE')

    summaries.append({'run_token':token,'root':str(root),'audit_reader':audit_reader,'runtime_producer':{'expected_sha':expected,'staged_manifest_sha':stage_manifest['expected_head'],'native_binary_provenance':stage_manifest.get('binary_provenance'),'identity_basis':'STAGED_MANIFEST_AND_EACH_RECEIPT_AND_EXISTING_COMPLETION_MARKER'},'contact_execution_mode':mode,'aggregate_readback':aggregate_readback,'render_evidence':render_evidence,'completion_validation':{'status':'BLOCKED_MISSING_COMPLETION' if missing_completion else ('FAIL' if any(e['check']=='COMPLETION_MARKER' for e in errors) else 'PASS'),'actual_process_markers':completion_markers,'missing_process_completion':missing_completion,'child_batch_markers_expected':False if mode=='SINGLE_PROCESS_ALL_BATCHES' else True},'missing_completion_batches':missing_completion,'counts':dict(stats),'decisions':dict(decisions),'reasons':dict(reasons),'asset_decisions':{k:dict(v) for k,v in assets.items()},'metric_ranges':{k:[min(v),max(v)] for k,v in spans.items() if v},'error_types':dict(Counter(e['check'] for e in errors)),'error_count':len(errors),'first_errors':errors[:15],'source_hashes':source_hashes})
print(json.dumps(summaries,indent=2))

