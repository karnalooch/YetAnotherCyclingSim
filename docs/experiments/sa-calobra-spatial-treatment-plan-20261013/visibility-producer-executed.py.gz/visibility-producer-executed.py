"""Sampled terrain visibility for the existing TPP cameras; planning only."""
import argparse
import csv
import json
import math
from pathlib import Path
import numpy as np
import rasterio
from build_sa_calobra_spatial_treatment_plan import digest, verified, read_raster, png_bytes
import base64


def ray_visibility(z, distance, camera_z, lift=0):
    """Strict running horizon; NoData blocks all subsequent samples."""
    valid = np.isfinite(z) & (z > -32000)
    slopes = np.where(valid, (z-camera_z)/distance, np.inf)
    previous = np.concatenate([np.full((z.shape[0],1), -np.inf), np.maximum.accumulate(slopes,axis=1)[:,:-1]],axis=1)
    return valid & (((z+lift-camera_z)/distance) >= previous-1e-6)


def build(root, output):
    if output.exists():
        raise FileExistsError('Preserve previous visibility output')
    plan_path=root/'docs/experiments/sa-calobra-spatial-treatment-plan-20261013/spatial-plan.json'
    plan=json.loads(plan_path.read_text(encoding='utf-8'))
    for s in plan['sources']:
        verified(root/Path(s['path']), s['sha256'])
    norm=Path(plan['sources'][3]['path'])
    manifest=json.loads(norm.read_text(encoding='utf-8'))
    record=next(r for r in manifest['outputs'] if r['path']=='elevation.tif')
    elevation=verified(norm.parent/'elevation.tif',record['sha256'])
    terrain=read_raster(elevation)
    csv_path=root/'docs/experiments/sa-calobra-tpp-survey-20261008/frames.csv'
    obs_path=root/'docs/experiments/sa-calobra-detail-planning-map-20261008/planning-data.json'
    obs=json.loads(obs_path.read_text(encoding='utf-8'))
    verified(csv_path,obs['source_csv_sha256'])
    rows=list(csv.DictReader(csv_path.open(encoding='utf-8',newline='')))
    if len(rows)!=1338 or len({r['frame_id'] for r in rows})!=1338:
        raise ValueError('Survey camera inventory differs')
    n=505
    hits=np.zeros((n,n),np.uint16)
    tested=np.zeros((n,n),np.uint16)
    elevated=np.zeros((n,n),np.uint16)
    pixels=np.zeros((n,n),np.float32)
    nearest=np.full((n,n),np.inf,np.float32)
    witness=np.full((n,n),-1,np.int16)
    distance=np.arange(1.,2854.,1.,dtype=np.float32)[None,:]
    per_frame=[]
    output.mkdir(parents=True)
    for i,row in enumerate(rows):
        c=np.array(json.loads(row['camera_location_cm']),float)/100
        t=np.array(json.loads(row['target_cm']),float)/100
        forward=t-c; forward/=np.linalg.norm(forward)
        right=np.cross([0,0,1],forward); right/=np.linalg.norm(right)
        up=np.cross(forward,right)
        hfov=math.radians(float(row['fov_deg']))
        vfov=2*math.atan(math.tan(hfov/2)*int(row['height_px'])/int(row['width_px']))
        center=math.atan2(forward[1],forward[0])
        # Wider than horizontal FOV: actual 3D projection below filters pitch effects.
        angles=center+np.deg2rad(np.arange(-50,50.001,.25,dtype=np.float32))
        x=c[0]+np.cos(angles[:,None])*distance
        y=c[1]+np.sin(angles[:,None])*distance
        cc=np.rint(x*2).astype(np.int32); rr=np.rint(y*2).astype(np.int32)
        inside=(rr>=0)&(rr<4033)&(cc>=0)&(cc<4033)
        z=terrain[np.clip(rr,0,4032),np.clip(cc,0,4032)]
        z=np.where(inside,z,np.nan)
        dz=z-c[2]
        dx=x-c[0]; dy=y-c[1]
        depth=dx*forward[0]+dy*forward[1]+dz*forward[2]
        lateral=dx*right[0]+dy*right[1]+dz*right[2]
        vertical=dx*up[0]+dy*up[1]+dz*up[2]
        frustum=inside&(depth>0)&(np.abs(lateral)<=depth*math.tan(hfov/2))&(np.abs(vertical)<=depth*math.tan(vfov/2))
        visible=ray_visibility(z,distance,c[2])&frustum
        # Raised object may emerge even when its ground is occluded. Review only.
        lifted=ray_visibility(z,distance,c[2],2)&frustum
        bins=(rr//8)*n+cc//8
        flat=visible.ravel()
        ids=bins.ravel()[flat]
        unique=np.unique(ids)
        hits.ravel()[unique]+=1
        tested.ravel()[np.unique(bins[frustum])]+=1
        elevated.ravel()[np.unique(bins[lifted])]+=1
        depth_visible=depth.ravel()[flat]
        scale=int(row['width_px'])/(2*math.tan(hfov/2))/np.maximum(depth_visible,1)
        np.maximum.at(pixels.ravel(),ids,scale)
        np.minimum.at(nearest.ravel(),ids,np.broadcast_to(distance,visible.shape).ravel()[flat])
        unset=unique[witness.ravel()[unique]<0]; witness.ravel()[unset]=i
        per_frame.append({'frame_id':row['frame_id'],'visible_4m_bins':len(unique),'direction':row['direction'],'window_id':row['window_id']})
        if i%50==0:
            (output/'progress.json').write_text(json.dumps({'processed':i+1,'total':len(rows)}))
            print(f'{i+1}/{len(rows)} cameras',flush=True)
    selector=Path(plan['sources'][0]['path'])
    sm=json.loads(selector.read_text(encoding='utf-8'))
    def coarse(a):
        padded=np.pad(a,((0,7),(0,7)),constant_values=False)
        return padded.reshape(n,8,n,8).any(axis=(1,3))
    cliff=coarse(read_raster(selector.parent/'cliff-candidate.tif')==1)
    scree=coarse(read_raster(selector.parent/'scree-candidate.tif')==1)
    reasons=read_raster(Path(plan['sources'][2]['path']))
    protected=coarse((reasons&63)!=0)
    road=coarse((reasons&1)!=0)
    unknown=coarse(read_raster(selector.parent/'cliff-candidate.tif')==255)
    # Operational proposals, not geological labels, placement masks or accepted LODs.
    treatment=np.zeros((n,n),np.uint8)
    treatment[hits>0]=1
    treatment[(hits>0)&cliff]=2
    treatment[(hits>0)&scree&(pixels>=8)]=3
    treatment[(hits==0)&(elevated>0)&(cliff|scree)]=4
    treatment[protected]=5
    treatment[unknown]=6
    labels={0:'Unresolved: no sampled visible-ground hit; retain baseline',1:'Material-first proposal: visible terrain; no selected cliff/near scree requirement',2:'Cliff mesh review: visible steep/rough source candidate; preserve major forms',3:'Rock trial review: visible scree candidate; 1 m feature projects to >=8 px',4:'Raised-form review: 2 m form may emerge above occluded ground',5:'Hard exclusions: no placement',6:'Unknown terrain neighborhood: no placement'}
    colors=np.array([[55,66,76],[82,132,126],[223,124,71],[235,198,86],[172,95,180],[105,115,130],[180,50,80]],np.uint8)
    np.savez_compressed(output/'visibility-arrays.npz',hits=hits,tested=tested,elevated=elevated,pixels_per_m=pixels,nearest_m=nearest,witness=witness,treatment=treatment)
    layer=[]
    for k,label in labels.items():
        rgba=np.zeros((n,n,4),np.uint8); mask=treatment==k
        rgba[mask,:3]=colors[k]; rgba[mask,3]=220
        url='data:image/png;base64,'+base64.b64encode(png_bytes(rgba)).decode()
        layer.append({'id':f'visibility-{k}','label':label,'cells':int(mask.sum()),'url':url})
    summary={'status':'SAMPLED_TERRAIN_VISIBILITY_TREATMENT_PROPOSAL','issue':365,'milestone':'M3','frames':len(rows),'station_pairs':669,'windows':185,'grid_cell_m':4,'ray_step_m':1,'ray_angle_step_deg':.25,'sources':[{'path':str(p),'sha256':digest(p)} for p in (plan_path,csv_path,elevation,selector)],'counts':{labels[k]:int((treatment==k).sum()) for k in labels},'limits':['TPP camera poses, not a continuous rider traversal or look-around proof','Base_DTM only; excludes v8 mesh, earthworks, buildings and vegetation occluders','Radial 1 m/.25 degree sampling and 4 m bins; sampled hits do not prove every point in a bin','No observed hit is unresolved, never confirmed hidden D','Material-first is a review proposal; visibility cannot establish geological need or geometry correctness','2 m raised-form test is a diagnostic proxy, not an asset-placement test','Original PNG correspondence and live native checks required before regional placement'],'placement':False,'qualified_assets':[],'performance_pass':False,'layers':[{k:v for k,v in l.items() if k!='url'} for l in layer]}
    (output/'visibility-plan.json').write_text(json.dumps(summary,indent=2)+'\n')
    (output/'frame-coverage.json').write_text(json.dumps(per_frame,separators=(',',':')))
    # Extend the existing artifact with separately switchable, correctly registered layers.
    page=(plan_path.parent/'spatial-plan.html').read_text(encoding='utf-8')
    imgs=''.join(f'<image id="{l["id"]}" x="-.25" y="-.25" width="2020" height="2020" href="{l["url"]}"/>' for l in layer)
    legend='<h2>Sampled visibility / proposed treatment</h2><p>1338 TPP cameras · 669 paired stations · 185 disconnected windows. 4 m planning bins. Every class requires review; no regional planting authorization.</p>'+''.join(f'<label><input type="checkbox" checked data-layer="{l["id"]}">{l["label"]}<small>{l["cells"]:,} planning bins</small></label>' for l in layer)+'<details><summary>Analysis limits</summary><ul>'+''.join(f'<li>{s}</li>' for s in summary['limits'])+'</ul></details>'
    page=page.replace('<g id="observations">',imgs+'<g id="observations">').replace('<h2>Physical raster areas</h2>',legend+'<h2>Original source candidates</h2>')
    page=page.replace('Sa Calobra — where to investigate rock treatment','Sa Calobra — sampled visibility and treatment proposals')
    (output/'spatial-plan.html').write_text(page,encoding='utf-8')
    (output/'progress.json').write_text(json.dumps({'processed':len(rows),'total':len(rows),'status':'COMPLETE'}))
    print(json.dumps(summary['counts']),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path('.'));p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();build(args.root.resolve(),args.output)
